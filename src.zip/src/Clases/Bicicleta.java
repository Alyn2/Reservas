package Clases;

import java.time.LocalDate;

public class Bicicleta  {

    private int chasis;
    private String marca;
    private String modelo;
    private LocalDate fechaUltimoMantenimiento;
    private String estado;

    public Bicicleta(int chasis, String marca, String modelo, LocalDate fechaUltimoMantenimiento, String estado) {       
        this.chasis = chasis;
        this.marca = marca;
        this.modelo = modelo;
        this.fechaUltimoMantenimiento = fechaUltimoMantenimiento;
        this.estado = estado;
    }

    public int getChasis() {
        return chasis;
    }

    public void setChasis(int chasis) {
        this.chasis = chasis;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public LocalDate getFechaUltimoMantenimiento() {
        return fechaUltimoMantenimiento;
    }

    public void setFechaUltimoMantenimiento(LocalDate fechaUltimoMantenimiento) {
        this.fechaUltimoMantenimiento = fechaUltimoMantenimiento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "chasis=" + chasis + ", marca=" + marca + ", modelo=" + modelo + ", fechaUltimoMantenimiento=" + fechaUltimoMantenimiento + ", estado=" + estado;
    }

}
