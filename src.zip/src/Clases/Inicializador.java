package Clases;

import javax.swing.JOptionPane;
import Clases.Bicicleta;
import Clases.Usuario;
import Clases.Reserva;
import java.time.LocalDate;
import java.util.ArrayList;

public class Inicializador {

    public static void iniciarUsuario(ArrayList<Usuario> listausuario) {
        listausuario.add(new Usuario("romario", 1234, "alpes", "romario@", 1234, "bien"));
        listausuario.add(new Usuario("smith", 12345, "belen", "smith@", 12345, "bien"));
        listausuario.add(new Usuario("juan", 234, "medellin", "juan@", 1454, "biennn"));
        listausuario.add(new Usuario("samuel", 1674, "alpes", "samuel@", 122134, "bieccn"));
        listausuario.add(new Usuario("neyson", 87634, "publado", "neyson@", 123434, "bien"));

    }

    public static void iniciarBicicleta(ArrayList<Bicicleta> listabicicleta) {
        listabicicleta.add(new Bicicleta(600, "as23", "aasa", LocalDate.now(), "Disponible"));
        listabicicleta.add(new Bicicleta(601, "aaa", "bbb", LocalDate.now(), "Disponible"));
        listabicicleta.add(new Bicicleta(602, "vvv", "mmm", LocalDate.now(), "Dañada"));
        listabicicleta.add(new Bicicleta(603, "rrr", "sss", LocalDate.now(), "Reparación"));
        listabicicleta.add(new Bicicleta(604, "ddd", "fffg", LocalDate.now(), "Dañada"));
    }

}
