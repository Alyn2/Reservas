
package Clases;

import java.time.LocalDate;
import java.util.Date;


public class Reserva {
    private int id;
    private Usuario usuario;
    private Date fechainicio;
    private Date fechafin;
    private String estado;
    private Bicicleta bicicleta;
    private LocalDate fechadeentrega;
    private String estadoFinalizacion;
    private String novedad;

    public Reserva(int id, Usuario usuario, Date fechainicio, Date fechafin, String estado, Bicicleta bicicleta, LocalDate fechadeentrega, String estadoFinalizacion, String novedad) {
        this.id = id;
        this.usuario = usuario;
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.estado = estado;
        this.bicicleta = bicicleta;
        this.fechadeentrega = null;
        this.estadoFinalizacion = estadoFinalizacion;
        this.novedad = novedad;
    }

    public Bicicleta getBicicleta() {
        return bicicleta;
    }

    public void setBicicleta(Bicicleta bicicleta) {
        this.bicicleta = bicicleta;
    }
      
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Date getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(Date fechainicio) {
        this.fechainicio = fechainicio;
    }

    public Date getFechafin() {
        return fechafin;
    }

    public void setFechafin(Date fechafin) {
        this.fechafin = fechafin;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDate getFechadeentrega() {
        return fechadeentrega;
    }

    public void setFechadeentrega(LocalDate fechadeentrega) {
        this.fechadeentrega = fechadeentrega;
    }

    public String getNovedad() {
        return novedad;
    }

    public void setNovedad(String novedad) {
        this.novedad = novedad;
    }

    public String getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(String estadoFinalizacion) {
        this.estadoFinalizacion = estadoFinalizacion;
    }
    

    @Override
    public String toString() {
        return "id=" + id + ", usuario=" + usuario + ", fechainicio=" + fechainicio + ", fechafin=" + fechafin + ", estado=" + estado + ", bicicleta=" + bicicleta + ", fechadeentrega=" + fechadeentrega + ", estadoFinalizacion=" + estadoFinalizacion + ", novedad=" + novedad ;
    }

    
   

    
}
